const myAssignment = document.getElementById('myAssignment');
const myInput = document.getElementById('myInput');
const feedback = document.getElementById('feedback');

let assignments = [];
let counter = 0;

function init(){
  //
}

function inputHandler(evt){
  //
}

function makeSum(){
  //
}

function evaluate(){
  
}

function getNumber(){
  let number = Math.floor(Math.random()*9)+1;
  return number;
}

myInput.addEventListener('keydown',inputHandler,false);
